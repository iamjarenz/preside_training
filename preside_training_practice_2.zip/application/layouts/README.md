Layouts directory
=================
The layouts directory is used for defining ColdBox layouts. By default, your application will have a single 'main' layout, but you are free and encouraged to add more.