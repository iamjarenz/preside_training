i18n Directory
==============
The i18n directory is used for defining i18n resource bundles.

