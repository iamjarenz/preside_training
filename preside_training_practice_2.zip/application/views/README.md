Views directory
===============

This folder is used for all your ColdBox views. This may include views for PresideCMS features such as Widgets, form controls and page types.