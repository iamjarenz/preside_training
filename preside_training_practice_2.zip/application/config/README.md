Config directory
================

This directory is used for any PresideCMS configuration settings.