Handlers directory
==================

The handlers directory is for ColdBox handlers. This can also include handlers for PresideCMS features such as widgets, form controls and page types.